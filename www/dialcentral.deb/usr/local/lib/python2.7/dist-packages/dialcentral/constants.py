__pretty_app_name__ = "DialCentral"
__app_name__ = "dialcentral"
__version__ = "1.3.7"
__build__ = 1
__app_magic__ = 0xdeadbeef

IS_MAEMO = True
