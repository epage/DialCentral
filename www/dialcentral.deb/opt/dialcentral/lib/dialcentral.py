#!/usr/bin/env python
# -*- coding: utf-8 -*-


import sys


sys.path.append("/opt/dialcentral/lib")


import dialcentral_qt


if __name__ == "__main__":
	dialcentral_qt.run()
